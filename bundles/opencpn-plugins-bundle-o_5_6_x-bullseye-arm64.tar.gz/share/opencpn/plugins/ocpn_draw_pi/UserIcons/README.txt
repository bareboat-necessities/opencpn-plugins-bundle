These icons are here courtesy of "http://www.svrevelations.com/entry/opencpn-user-icons"
