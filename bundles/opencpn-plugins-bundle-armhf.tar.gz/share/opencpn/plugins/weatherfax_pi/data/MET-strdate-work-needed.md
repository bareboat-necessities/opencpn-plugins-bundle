Australia BOM
France MET
Singapore Met
India Met
UK Met
Japanese Met

====================================

<Server Name="Australia bom" Url="http://www.bom.gov.au/charts_data/">
    <Region Name="Australia">
<!-- not supported yet
 <Map Url="gms/IDE00135.%Y%M%D%H30.jpg" Contents="Satellite Image" /> -->
 
    http://www.bom.gov.au/marine/wind.shtml?location=wa1&tz=AEDT 

Aus BOM Index
http://www.bom.gov.au/australia/charts/index.shtml
http://www.bom.gov.au/australia/charts/nwp_products.shtml
http://www.bom.gov.au/australia/charts/synoptic_col.shtml

B&W MSLP for next 4 days
http://www.bom.gov.au/australia/charts/4day_bw.shtml   Multiple image
http://www.bom.gov.au/fwo/IDG00073.gif?2018-Jan-27-01:53:05   <---Typical URL
http://www.bom.gov.au/fwo/IDG00073.gif?2017-Aug-01-01:45:32  Multiple image
http://www.bom.gov.au/fwo/IDG00073.gif?2017-Aug-01-01:45:32

Latest Forecast 
http://www.bom.gov.au/australia/charts/synoptic_col.shtml
http://www.bom.gov.au/fwo/IDY00030.201801271200.png   <---Typical URL
Color

B&W
http://www.bom.gov.au/difacs/IDX0894.gif
http://www.bom.gov.au/difacs/IDX0894.gif  <--- Typical URL
Short term Forecast 36hrs
http://www.bom.gov.au/australia/charts/msl_36hr_forecast.shtml
http://www.bom.gov.au/fwo/IDG00104.png?2018-Jan-27-01:50:09   <---Typical URL
http://www.bom.gov.au/fwo/IDG00104.png?2017-Aug-01-01:09:41 color
http://www.bom.gov.au/fwo/IDG00103.png?2017-Aug-01-01:09:41 b&W



Global Model Interactive Forecast Maps
http://www.bom.gov.au/australia/charts/viewer/index.shtml?type=mslp-thick&tz=UTC&area=Au&model=G
http://www.bom.gov.au/charts_data/IDY20002/current/mslp-thick/IDY20002.mslp-thick.000.png?1517011200 <---Typ Url
12utc Tues 1 Today
http://www.bom.gov.au/charts_data/IDY20002/current/mslp-thick/IDY20002.mslp-thick.000.png?1501588800
12utc Wed 2
http://www.bom.gov.au/charts_data/IDY20002/current/mslp-thick/IDY20002.mslp-thick.024.png?1501588800
12utc Thur 3
http://www.bom.gov.au/charts_data/IDY20002/current/mslp-thick/IDY20002.mslp-thick.048.png?1501588800
http://www.bom.gov.au/charts_data/IDY20002/current/mslp-thick/IDY20002.mslp-thick.048.png?1501588800
Nope they are not unique.
http://www.bom.gov.au/australia/charts/viewer/index.shtml?type=mslp-thick&tz=UTC&area=Au&model=G
http://www.bom.gov.au/charts_data/IDY20002/current/mslp-thick/IDY20002.mslp-thick.072.png?1501588800
It is just swapping the new image in using the same name!

Southern Hemisphere MSLP Forecast Maps
Surface Pressure & Rainfall
http://www.bom.gov.au/australia/charts/viewer/index.shtml?type=mslp-precip&tz=AEDT&area=SH&model=G
http://www.bom.gov.au/charts_data/IDY20001/current/mslp-precip/IDY20001.mslp-precip.006.png?1501588800
MLSP & thickness
http://www.bom.gov.au/australia/charts/viewer/index.shtml?type=mslp-thick&tz=AEDT&area=SH&model=G&chartSubmit=Refresh+View
http://www.bom.gov.au/charts_data/IDY20001/current/mslp-thick/IDY20001.mslp-thick.000.png?1501588800

Indian Ocean MSLP
http://www.bom.gov.au/australia/charts/indian_ocean.shtml
Pacific Ocean MSLP
http://www.bom.gov.au/australia/charts/pacific_ocean.shtml
Asia MSLP Analysis
http://www.bom.gov.au/australia/charts/darwin_MSLP_00z.shtml

Gradiant Wind Analyis 00z
http://www.bom.gov.au/australia/charts/glw_00z.shtml
Gradiant Windd Analysis 12z
http://www.bom.gov.au/australia/charts/glw_12z.shtml
Pacific Ocean Gradiant Wind 00z
http://www.bom.gov.au/australia/charts/pacific_ocean_glw_00z.shtml
Pacific Ocean Gradiant Wind 12z
http://www.bom.gov.au/australia/charts/pacific_ocean_glw_12z.shtml
Indian Ocean Gradiant Wind 00z
http://www.bom.gov.au/australia/charts/indian_ocean_glw_00z.shtml
Indian Ocean Gradiant Wind 12z
http://www.bom.gov.au/australia/charts/indian_ocean_glw_12z.shtml


---
Marine Wind Forecast Time Zone UTC  Region - Australia  (many regions available)
http://www.bom.gov.au/marine/wind.shtml?unit=p0&location=nt&tz=UTC
http://www.bom.gov.au/marine/wind.shtml?unit=p0&location=aus&tz=UTC
Interactive Wave Significant Heights  Region- Australia   Time Zone
http://www.bom.gov.au/australia/charts/viewer/index.shtml?type=sigWaveHgt&tz=AEDT&area=Au&model=CG&chartSubmit=Refresh+View
Surf Press & Rainfall
http://www.bom.gov.au/australia/charts/viewer/index.shtml?type=mslp-precip&tz=ACST&area=Au&model=CG&chartSubmit=Refresh+View	
Surface Winds
http://www.bom.gov.au/australia/charts/viewer/index.shtml?type=windarrow&level=10m&tz=ACST&area=Au&model=CG&chartSubmit=Refresh+View
MSLP & Thickness
http://www.bom.gov.au/australia/charts/viewer/index.shtml?type=mslp-thick&tz=ACST&area=Au&model=CG&chartSubmit=Refresh+View
Wind, Wave & Height & Direction
http://www.bom.gov.au/australia/charts/viewer/index.shtml?type=windWave&tz=ACST&area=Au&model=CG&chartSubmit=Refresh+View
---
Typical image location
http://www.bom.gov.au/charts_data/IDY30100/current/windWave/IDY30100.windWave.000.png?1501610400
However this downloads typically.
http://www.bom.gov.au/charts_data/IDY30100/current/windWave/IDY30100.windWave.000.png
	-->


<!--  FRANCE Met
incomplete since these services use changing urls and are therefore not easily supported
http://www.meteofrance.fr/
  <Server Name="meteo france" Url="http://www.meteofrance.com/integration/sim-portail/generated/integration/img/produits/mer/">
    <Region Name="Atlantique" Url="atl">
      <Map Url="vent_BC6HOI49D49.gif" Contents="0h Vent et Isobars" />
    </Region>
  </Server>
<Server Name="NZ met service" Url="">
-->  
  
<!-- SINGAPORE MET
  <Server Name="Singapore Met" Url="http://www.weather.gov.sg/wip/pp/">
    <Region Name="Singapore">
      <Map Url="rndops/web/ship/gif/swind01.gif" Contents="Surface Wind Forecast 24hr" Area="3" />
      <Map Url="rndops/web/ship/gif/swind02.gif" Contents="Surface Wind Forecast 48hr" Area="3" />
      <Map Url="rndops/web/ship/gif/ship01.gif" Contents="Significant Wave Forecast 24hr" Area="1" />
      <Map Url="rndops/web/ship/gif/ship02.gif" Contents="Significant Wave Forecast 48hr" Area="1" />
      <Map Url="rndops/web/ship/gif/wxchart.gif" Contents="Region Weather Chart" Area="2" />
	 
      <Area Name="1" lat1="20S" lat2="40N" lon1="80E" lon2="150E" />
      <Area Name="2" lat1="15S" lat2="35N" lon1="90E" lon2="130E" />
      <Area Name="3" lat1="20S" lat2="40N" lon1="80E" lon2="150E" />
    </Region>
  </Server>
-->
  
<!-- INDIA MET
  <Server Name="India Meteorological Dep" Url="http://www.imd.gov.in/section/satmet/img/">
    <Region Name="Asia Sector">
      <Map Url="3Dasiasec_vis.jpg" Contents="Visible" Area="1" />
      <Map Url="3Dasiasec_swir.jpg" Contents="Short Wave IR" Area="1" />
      <Map Url="3Dasiasec_mir.jpg" Contents="Mid IR" Area="1" />
      <Map Url="3Dasiasec_wv.jpg" Contents="Water Vapor" Area="1" />
      <Map Url="3Dasiasec_ir1.jpg" Contents="IR 10.3-11.3 um" Area="1" />
      <Map Url="3Dasiasec_ir2.jpg" Contents="IR 11.5-12.5 um" Area="1" />
      <Map Url="3Dasiasec_rgb.jpg" Contents="Colour Composite" Area="1" />
      <Area Name="1" lat1="10S" lat2="45N" lon1="45E" lon2="105E" />
    </Region>
    <Region Name="NWQ">
      <Map Url="3Dnwqsec_vis.jpg" Contents="Visible" Area="1" />
      <Map Url="3Dnwqsec_swir.jpg" Contents="Short Wave IR" Area="1" />
      <Map Url="3Dnwqsec_mir.jpg" Contents="Mid IR" Area="1" />
      <Map Url="3Dnwqsec_wv.jpg" Contents="Water Vapor" Area="1" />
      <Map Url="3Dnwqsec_ir1.jpg" Contents="IR 10.3-11.3 um" Area="1" />
      <Map Url="3Dnwqsec_ir2.jpg" Contents="IR 11.5-12.5 um" Area="1" />
      <Map Url="3Dnwqsec_rgb.jpg" Contents="Colour Composite" Area="1" />
      <Area Name="1" lat1="20S" lat2="45N" lon1="15E" lon2="85E" />
    </Region>
    <Region Name="NEQ">
      <Map Url="3Dneqsec_vis.jpg" Contents="Visible Radar" Area="1" />
      <Map Url="3Dneqsec_vis.jpg" Contents="Visible" Area="1" />
      <Map Url="3Dneqsec_swir.jpg" Contents="Short Wave IR" Area="1" />
      <Map Url="3Dneqsec_mir.jpg" Contents="Mid IR" Area="1" />
      <Map Url="3Dneqsec_wv.jpg" Contents="Water Vapor" Area="1" />
      <Map Url="3Dneqsec_ir1.jpg" Contents="IR 10.3-11.3 um" Area="1" />
      <Map Url="3Dneqsec_ir2.jpg" Contents="IR 11.5-12.5 um" Area="1" />
      <Map Url="3Dneqsec_rgb.jpg" Contents="Colour Composite" Area="1" />
      <Area Name="1" lat1="5N" lat2="35N" lon1="75E" lon2="105E" />
    </Region>
  </Server>
-->  

<!--  UK MET CHARTS ALTERNATIVE
Also try  http://www1.wetter3.de/fax.html
UK Met Polar files  Germain, Canada, Japan etc.
-->

<!-- UK MET

 UK MET OFFICE
 
 Surface Pressure Analysis Chart UTC 00 current day  overall
 https://www.metoffice.gov.uk/public/weather/surface-pressure/#?tab=surfacePressureColour&fcTime=1516986000
 https://www.metoffice.gov.uk/public/weather/surface-pressure/#?tab=surfacePressureColour&fcTime=1516986000
 Surf Press Analy B&W Utc00  current day   overeall
 http://www.metoffice.gov.uk/public/data/CoreProductCache/BWSurfacePressureChart/Item/ProductId/63553370
 Surf Press Analy Color Utc00  current day   overeall
 http://www.metoffice.gov.uk/public/data/CoreProductCache/SurfacePressureChart/Item/ProductId/63553369
 
 
Metoffice requires year month day time to set correct url  - Not found now
http://www.metoffice.gov.uk/weather/images/namerica_sat_201405240600.jpg
http://www.metoffice.gov.uk/weather/images/namerica_sat_201405240000.jpg
http://www.metoffice.gov.uk/weather/images/namerica_sat_201405231800.jpg

=======
UK MET MOBILE  - LETS USE THESE!!  MOBILE WEBSITE
=====================================================
Analysis chart Issued at: 1200 on Tue 1 Aug 2017  Color
https://www.metoffice.gov.uk/public/data/CoreProductCache/SurfacePressureChart/Item/ProductId/54062187

Analysis chart Issued at: 1200 on Tue 1 Aug 2017  B&W
https://www.metoffice.gov.uk/public/data/CoreProductCache/BWSurfacePressureChart/Item/ProductId/54062186

This is the chart from the main website....
http://www.metoffice.gov.uk/public/data/CoreProductCache/SurfacePressureChart/Item/ProductId/54062187

Forecast chart T+12  Issued at: 1200 on Tue 1 Aug 2017 Color
https://www.metoffice.gov.uk/public/data/CoreProductCache/SurfacePressureChart/Item/ProductId/54069714

Analysis chart  Issued at: 1200 on Tue 1 Aug 2017 B&W
Image Source:
https://www.metoffice.gov.uk/public/data/CoreProductCache/BWSurfacePressureChart/Item/ProductId/54062186
<li class="chart0" data-value="1200 on Tue 1 Aug" style="display: list-item;">
<h2 class="no-js" style="display: none;">1200 on Tue 1 Aug 2017</h2>
<h2>Analysis chart</h2>
<p>Issued at: 1200 on Tue 1 Aug 2017</p>
<img src="https://www.metoffice.gov.uk/public/data/CoreProductCache/BWSurfacePressureChart/Item/ProductId/54062186" alt="Surface pressure - Analysis chart">
</li>

Forecast chart T+24  Issued at: 1200 on Tue 1 Aug 2017  B&W
https://www.metoffice.gov.uk/public/data/CoreProductCache/BWSurfacePressureChart/Item/ProductId/54068879

Forecast chart T+36  Issued at: 1200 on Tue 1 Aug 2017  B&W
https://www.metoffice.gov.uk/public/data/CoreProductCache/BWSurfacePressureChart/Item/ProductId/54071232

Forecast chart T+48  Issued at: 1200 on Tue 1 Aug 2017 B&W
https://www.metoffice.gov.uk/public/data/CoreProductCache/BWSurfacePressureChart/Item/ProductId/54071231

Forecast chart T+60  Issued at: 1200 on Tue 1 Aug 2017  B&W
https://www.metoffice.gov.uk/public/data/CoreProductCache/BWSurfacePressureChart/Item/ProductId/54072110

Forecast chart T+72  Issued at: 1200 on Tue 1 Aug 2017  B&W
https://www.metoffice.gov.uk/public/data/CoreProductCache/BWSurfacePressureChart/Item/ProductId/54072108

Forecast chart T+96  Issued at: 1200 on Tue 1 Aug 2017 B&W
https://www.metoffice.gov.uk/public/data/CoreProductCache/BWSurfacePressureChart/Item/ProductId/54080867

Forecast chart T+120  Issued at: 1200 on Tue 1 Aug 2017
https://www.metoffice.gov.uk/public/data/CoreProductCache/BWSurfacePressureChart/Item/ProductId/54082080

Satellite
http://www.metoffice.gov.uk/barometer/uk-storm-centre
http://www.metoffice.gov.uk/binaries/content/gallery/mohippo/images/barometer/uk-storm-centre/name_our_storms_950x560px.jpg/name_our_storms_950x560px.jpg/mohippo%3Abarometerheroimage
=====
-->


<!--

NOT fOUND

  <Server Name="metoffice.gov.uk" Url="http://www.metoffice.gov.uk/public/data/CoreProductCache/BWSurfacePressureChart/Item/ProductId/">
    <Region Name="UK">
      <Map Url="39951127" Contents="Analysis Chart 00z" Area="2" />
      <Map Url="39956171" Contents="Forecast Chart 12z" Area="1" />
      <Map Url="39956047" Contents="Forecast Chart 24z" Area="1" />
      <Map Url="39956843" Contents="Forecast Chart 36z" Area="1" />
      <Map Url="39957148" Contents="Forecast Chart 48z" Area="1" />
      <Map Url="39957857" Contents="Forecast Chart 60z" Area="1" />
      <Map Url="39958279" Contents="Forecast Chart 72z" Area="1" />
      <Map Url="39963794" Contents="Forecast Chart 84z" Area="1" />
      <Map Url="39964232" Contents="Forecast Chart 84z" Area="1" />  

      <Area Name="1" lat1="40N" lat2="70N" lon1="60W" lon2="40E" />
      <Area Name="2" lat1="40N" lat2="70N" lon1="60W" lon2="40E" />
    </Region>
  </Server>
-->


<!-- UK Met 
Analysis & 5 days of forecast charts are updated every 12 hours around 0730 UTC and 1930 UTC, with the exception  day four and five charts which are only issued once per day at 1930 UTC.

Find current day utc0000   -these work now
https://www.metoffice.gov.uk/public/weather/surface-pressure/#?tab=surfacePressureBW&fcTime=1516986000   B&W surface URL
http://www.metoffice.gov.uk/public/data/CoreProductCache/BWSurfacePressureChart/Item/ProductId/63553370 <---b&w SURFACE TYPICAL url
Surface pressure chart - Forecast T+12 - Issued at: 19:00 on Fri 26 Jan 2018	
http://www.metoffice.gov.uk/public/data/CoreProductCache/BWSurfacePressureChart/Item/ProductId/63560438 
Surface pressure chart - Forecast T+24 - Issued at: 19:00 on Fri 26 Jan 2018
http://www.metoffice.gov.uk/public/data/CoreProductCache/BWSurfacePressureChart/Item/ProductId/63561052
Surface pressure chart - Forecast T+36 - Issued at: 19:00 on Fri 26 Jan 2018
http://www.metoffice.gov.uk/public/data/CoreProductCache/BWSurfacePressureChart/Item/ProductId/63561670

No longer found!!
http://www.metoffice.gov.uk/public/data/CoreProductCache/SurfacePressureChart/Item/ProductId/53818112  Analysis
http://www.metoffice.gov.uk/public/data/CoreProductCache/SurfacePressureChart/Item/ProductId/53824097  T=12
http://www.metoffice.gov.uk/public/data/CoreProductCache/SurfacePressureChart/Item/ProductId/53824002  T=24
http://www.metoffice.gov.uk/public/data/CoreProductCache/SurfacePressureChart/Item/ProductId/53824999  T=36
http://www.metoffice.gov.uk/public/data/CoreProductCache/SurfacePressureChart/Item/ProductId/53824960  T=48
http://www.metoffice.gov.uk/public/data/CoreProductCache/SurfacePressureChart/Item/ProductId/53826620  T=60
http://www.metoffice.gov.uk/public/data/CoreProductCache/SurfacePressureChart/Item/ProductId/53826612  T=72
http://www.metoffice.gov.uk/public/data/CoreProductCache/SurfacePressureChart/Item/ProductId/53833720  T=96
http://www.metoffice.gov.uk/public/data/CoreProductCache/SurfacePressureChart/Item/ProductId/53833717  T=120

black and white  - no longer found
http://www.metoffice.gov.uk/public/data/CoreProductCache/BWSurfacePressureChart/Item/ProductId/53818126 Analysis
http://www.metoffice.gov.uk/public/data/CoreProductCache/BWSurfacePressureChart/Item/ProductId/53824096 T12
http://www.metoffice.gov.uk/public/data/CoreProductCache/BWSurfacePressureChart/Item/ProductId/53824003 T24
http://www.metoffice.gov.uk/public/data/CoreProductCache/BWSurfacePressureChart/Item/ProductId/53824998 T36
http://www.metoffice.gov.uk/public/data/CoreProductCache/BWSurfacePressureChart/Item/ProductId/53824961 T48
http://www.metoffice.gov.uk/public/data/CoreProductCache/BWSurfacePressureChart/Item/ProductId/53826619 T60
http://www.metoffice.gov.uk/public/data/CoreProductCache/BWSurfacePressureChart/Item/ProductId/53826614 T72
http://www.metoffice.gov.uk/public/data/CoreProductCache/BWSurfacePressureChart/Item/ProductId/53833719 T96
http://www.metoffice.gov.uk/public/data/CoreProductCache/BWSurfacePressureChart/Item/ProductId/53833718 T120

Issued  20:00 Thurs July 27  GMT  -no longer found
http://www.metoffice.gov.uk/public/data/CoreProductCache/BWSurfacePressureChart/Item/ProductId/53841136  Analysis
http://www.metoffice.gov.uk/public/data/CoreProductCache/BWSurfacePressureChart/Item/ProductId/53849078  T12
http://www.metoffice.gov.uk/public/data/CoreProductCache/BWSurfacePressureChart/Item/ProductId/53847914  T24
http://www.metoffice.gov.uk/public/data/CoreProductCache/BWSurfacePressureChart/Item/ProductId/53849794  T36
http://www.metoffice.gov.uk/public/data/CoreProductCache/BWSurfacePressureChart/Item/ProductId/53849792  T48
http://www.metoffice.gov.uk/public/data/CoreProductCache/BWSurfacePressureChart/Item/ProductId/53850434  T60
http://www.metoffice.gov.uk/public/data/CoreProductCache/BWSurfacePressureChart/Item/ProductId/53850421  T72
http://www.metoffice.gov.uk/public/data/CoreProductCache/BWSurfacePressureChart/Item/ProductId/53851225  T84

==
UK MET

World Satellite Images 
https://www.metoffice.gov.uk/public/weather/world-satellite/#?tab=satImg&map=regionalIR&fcTime=1517007600


  Surface Pressure Charts  (date dependent)
  http://www.metoffice.gov.uk/mobile/surface-pressure/   color  works!1
  https://www.metoffice.gov.uk/public/data/CoreProductCache/SurfacePressureChart/Item/ProductId/63553369  <---image url
  
  http://www.metoffice.gov.uk/public/data/CoreProductCache/SurfacePressureChart/Item/ProductId/38339496   <---now not found
  http://www.metoffice.gov.uk/public/data/CoreProductCache/SurfacePressureChart/Item/ProductId/38345811   <--- now not found
  
  http://www.metoffice.gov.uk/mobile/surface-pressure/   black and white   - Works
  https://www.metoffice.gov.uk/public/data/CoreProductCache/SurfacePressureChart/Item/ProductId/63553369    URL for photo

 
  
  Marine observations http://www.metoffice.gov.uk/mobile/marine/observations
  but cant use.
-->

<!-- JAPANESE MET
Japanese Met  http://www.jma.go.jp/jma/indexe.html
Same problem with numbers in the URL

Surface Pressure 1800utc Aug 1
http://www.jma.go.jp/en/g3/index.html
http://www.jma.go.jp/en/g3/images/asia/17080203.png

Surface Pressure 1200utc Aug 1
http://www.jma.go.jp/en/g3/images/asia/17080203.png
http://www.jma.go.jp/en/g3/images/asia/17080121.png

Surface Pressure 0600utc Aug 1
http://www.jma.go.jp/en/g3/images/asia/17080115.png
http://www.jma.go.jp/en/g3/images/asia/17080115.png

Surface Pressure 0000utc Aug 1
http://www.jma.go.jp/en/g3/images/asia/17080109.png
http://www.jma.go.jp/en/g3/images/asia/17080109.png

--
24hr Forecast
http://www.jma.go.jp/en/g3/images/24h/17080121.png
http://www.jma.go.jp/en/g3/images/24h/17080121.png
http://www.jma.go.jp/en/g3/images/24h/17080121.png

48hr Forecast
http://www.jma.go.jp/en/g3/images/48h/17080121.png
http://www.jma.go.jp/en/g3/images/48h/17080121.png

www.jma.go.jp requires year month day time for url 
-->

<!-- Ecowatch - Ocean surface temp.
      <Map Url="http://ecowatch.ncddc.noaa.gov/JAG/Navy/data/satellite_analysis/gsnofa.gif
-->
	