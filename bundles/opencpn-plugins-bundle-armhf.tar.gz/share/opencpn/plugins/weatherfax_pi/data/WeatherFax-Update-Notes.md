WeatherFax Update Notes:

The weatherfaxinternetretrieval.xml and weatherfaxschedules.xml files must be maintained and updated by all the USERS!
Contribute your special url's and schedules for the benefit of all.

1. Mauritius – Files exist confirmed via browser on the web, accessible vie the homepage within browser.  Directly URL access not possilbe….Protection of some sort?

2. Singapore – This needs work. Several charts, wave height and swell, no longer work. Format must has changed. The surface wind charts work.

3. Japan - Unable to calibrate the charts, format is not polar or anything similar. Also VERY small, numbers hard to read,  left at the best compromise

4. South Africa - Internals of the website must have changed, not able to get any access to the charts.

5. French Polynesia – same thing as in SA.

6. Chile – Polar file is hard to calibrate almost impossible to get a perfect mapping.

7. We need better coverage for Asia, Malysia and Japan.

8. We have lost some sources for Europe and could use more coverage.